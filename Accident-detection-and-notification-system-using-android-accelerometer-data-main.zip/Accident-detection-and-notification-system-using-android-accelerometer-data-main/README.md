# Steps that are include in this project
## 1. Access the android camera to Python using OpenCV
For accessing the android camera you can follow the steps given in<a href="https://mishraabhi8924.medium.com/access-the-android-camera-to-python-using-opencv-3d5901f01f23"> this blog</a>
## 2. About twilio messaging <a href="https://www.twilio.com/messaging-api">API</a>
